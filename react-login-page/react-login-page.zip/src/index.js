
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import App from './component/App';

import css from './css/style.css';

const root = document.getElementById('root');
ReactDOM.render(
    <div>
<App/>
</div>,
root
);

